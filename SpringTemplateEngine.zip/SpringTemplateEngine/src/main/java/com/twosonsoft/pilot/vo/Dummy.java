package com.twosonsoft.pilot.vo;

public class Dummy
{
	String a;
	String b;
	String c;
	public String getA()
	{
		return a;
	}
	public void setA(String a)
	{
		this.a = a;
	}
	public String getB()
	{
		return b;
	}
	public void setB(String b)
	{
		this.b = b;
	}
	public String getC()
	{
		return c;
	}
	public void setC(String c)
	{
		this.c = c;
	}
	
	
}
