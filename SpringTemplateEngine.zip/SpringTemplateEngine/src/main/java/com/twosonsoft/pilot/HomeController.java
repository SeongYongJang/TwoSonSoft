package com.twosonsoft.pilot;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.twosonsoft.pilot.util.CustomHttpServletResponseWrapper;
import com.twosonsoft.pilot.vo.Dummy;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController
{

	@Autowired
	InternalResourceViewResolver internalResourceViewResolver;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model)
	{
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "home";
	}

	@RequestMapping(value = "/jstl.do", method = RequestMethod.GET)
	public void jstl(HttpServletRequest request, HttpServletResponse response,  Locale locale) throws Exception
	{
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);
		
		System.out.println("JSTL mapping");
		
		// mapping data
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		Dummy dummy = new Dummy();		
		dummy.setA("a data");
		dummy.setB("b data");
		dummy.setC("c data");
		// add value
		mv.addObject("serverTime", formattedDate);
		
		// add object
		mv.addObject(dummy);
		
		// get view
		View view = internalResourceViewResolver.resolveViewName(mv.getViewName(), locale);
		HttpServletResponse localResponse = new CustomHttpServletResponseWrapper(response);
		
		// rendering view on server side
		view.render(mv.getModel(), request, localResponse);
		
		// get html string from response
		String html = localResponse.toString();
		
		System.out.println(html);
		
		// send html string to client if want
		//response.getWriter().write(html);
	}
	
	
	
}
