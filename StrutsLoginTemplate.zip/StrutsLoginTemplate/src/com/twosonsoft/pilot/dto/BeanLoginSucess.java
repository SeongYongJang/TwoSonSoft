package com.twosonsoft.pilot.dto;

public class BeanLoginSucess {
	String success; // request success string
	String loginYN; // login Y or N
}
