package com.twosonsoft.pilot.dto;

public class BeanLoginInfo {

	String id;	// member id
	String token;	// login token
	String uuid;		// device uuid
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	
}
