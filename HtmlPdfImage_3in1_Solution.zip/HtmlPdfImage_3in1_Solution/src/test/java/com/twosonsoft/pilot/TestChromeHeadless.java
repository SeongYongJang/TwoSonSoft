package com.twosonsoft.pilot;

import static java.nio.file.Files.write;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import io.webfolder.cdp.AdaptiveProcessManager;
import io.webfolder.cdp.Launcher;
import io.webfolder.cdp.MacOsProcessManagerPatch;
import io.webfolder.cdp.command.Animation;
import io.webfolder.cdp.command.CSS;
import io.webfolder.cdp.command.DOM;
import io.webfolder.cdp.command.Page;
import io.webfolder.cdp.session.Session;
import io.webfolder.cdp.session.SessionFactory;
import io.webfolder.cdp.type.page.GetLayoutMetricsResult;

public class TestChromeHeadless
{

	@Test
	public void test()
	{
		getPdfFromUrl("http://php.m2soft.co.kr/products/crownix-smartform-7");
	}

	public void getPdfFromUrl(String url)
	{

		// Path file = createTempFile("cdp4j", ".pdf");

		try
		{
			Launcher launcher = new Launcher();

			MacOsProcessManagerPatch processManager = new MacOsProcessManagerPatch();

			launcher.setProcessManager(processManager);

			List<String> args = new ArrayList<String>();
			args.add("--disable-gpu");
			args.add("--headless");

			SessionFactory factory = launcher.launch(args);

			String context = factory.createBrowserContext();
			try
			{
				Session session = factory.create(context);

				DOM dom = session.getCommand().getDOM();
				dom.enable();

				CSS css = session.getCommand().getCSS();
				css.enable();

				Animation ani = session.getCommand().getAnimation();

				ani.disable();

				// navigate url
				session.navigate(url);
				// wait page
				session.waitDocumentReady();
				// session.wait(10000); // wait 0.t second
				// change page metrics
				Page page = session.getCommand().getPage();
				page.setDeviceMetricsOverride(1024, 768, 1.0, false);

				// recalculate page metrics
				GetLayoutMetricsResult layout = page.getLayoutMetrics();

				int height = layout.getContentSize().getHeight().intValue();

				// change page metrics
				page.setDeviceMetricsOverride(1080, height, 1.0, false);

				// print web page
				byte[] content = page.printToPDF();
				// true, false, false, Double.valueOf("1.0"),
				// Double.valueOf("11.0"),
				// Double.valueOf("8.5"), Double.valueOf("0.0"),
				// Double.valueOf("0.0"),
				// Double.valueOf("0.0"), Double.valueOf("0.0"), "1-2", false,
				// "<span
				// class=title></span>", "<span class=pageNumber></span>",
				// false);

				Path path = Paths.get("/Users/seongyong/Downloads/crownix.pdf");

				write(path, content);
				System.out.println(path);
				session.close();
			}
			catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			factory.disposeBrowserContext(context);

			launcher.getProcessManager().kill();

		}
		catch (Exception e)
		{

		}

	}

}
