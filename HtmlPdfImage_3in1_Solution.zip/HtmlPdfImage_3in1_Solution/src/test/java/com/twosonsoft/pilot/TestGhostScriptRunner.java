package com.twosonsoft.pilot;

import java.util.List;

import org.junit.Test;

import com.twosonsoft.pilot.solution.converter.ImagesToTiff;
import com.twosonsoft.pilot.solution.converter.PDFToImageConverter;
import com.twosonsoft.pilot.solution.ghostscriptrunner.MacOsRunner;

public class TestGhostScriptRunner
{

	@Test
	public void test() throws Exception
	{
		String sourceFilename = "/Users/seongyong/Downloads/gcexceljava.pdf";
		String dpi = "150";

		// Testing pdf to png
		PDFToImageConverter pdfToImageConverter = new PDFToImageConverter(new MacOsRunner());

		pdfToImageConverter.setDefaultImageFormat(PDFToImageConverter.PNG);
		List<String> listImageFilename = pdfToImageConverter.convertPdf(sourceFilename, dpi);

		// Testing png to Tiff
		ImagesToTiff imgsToTiff = new ImagesToTiff();
		
		imgsToTiff.run(listImageFilename, "/Users/seongyong/Downloads/gcexceljava5.tiff");
	}

}
