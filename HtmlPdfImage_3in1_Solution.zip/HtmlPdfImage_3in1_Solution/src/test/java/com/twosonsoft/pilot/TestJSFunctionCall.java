package com.twosonsoft.pilot;

import org.junit.Test;

import com.twosonsoft.pilot.solution.converter.UrlToPdf;
import com.twosonsoft.pilot.solution.converter.VoUrlToPdfTask;

import io.webfolder.cdp.MacOsProcessManagerPatch;

public class TestJSFunctionCall
{


	
	@Test
	public void testUrlToPdfClass() throws Exception
	{
		// Testing url to pdf
		MacOsProcessManagerPatch processManager = new MacOsProcessManagerPatch();
		
		//
		// initialize Task
		VoUrlToPdfTask voUrlToPdfTask = new VoUrlToPdfTask();
		
		voUrlToPdfTask.setUrl("http://localhost:8080/pilot/hello.do");
		voUrlToPdfTask.setCompleteCheckString("true");
		voUrlToPdfTask.setLoadCompleteCheckJsFunctionName("getDone()");
		voUrlToPdfTask.setTargetFilename("/Users/seongyong/Downloads/e1.pdf");
		///////////////////////////////////////////////////////////////////////////
		
		UrlToPdf urlToPdf = new UrlToPdf(processManager);
		
		urlToPdf.doUrlToPdf(voUrlToPdfTask);
		
		
		
	}
	

}
