package com.twosonsoft.pilot.solution.ghostscriptrunner;

public interface GhostScriptRunner
{
	public String getGhostScriptPath();
}
