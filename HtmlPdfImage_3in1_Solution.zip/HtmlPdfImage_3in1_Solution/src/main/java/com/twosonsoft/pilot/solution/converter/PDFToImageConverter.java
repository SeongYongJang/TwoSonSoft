package com.twosonsoft.pilot.solution.converter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfReader;
import com.twosonsoft.pilot.solution.ghostscriptrunner.GhostScriptRunner;

public class PDFToImageConverter
{

	public static final String PNG = "png16m";
	public static final String JPG = "jpeg";
	
	List<String> listPngFilename = new ArrayList<String>();
	boolean isWide = false;

	GhostScriptRunner ghostScriptRunner;

	
	String defaultImageFormat = PDFToImageConverter.PNG;
	String imageExtension;
	
	
	public String getDefaultImageFormat()
	{
		return defaultImageFormat;
	}

	public void setDefaultImageFormat(String defaultImageFormat)
	{
		this.defaultImageFormat = defaultImageFormat;
	}

	public PDFToImageConverter(GhostScriptRunner ghostScriptRunner)
	{
		this.ghostScriptRunner =  ghostScriptRunner;
	}

	synchronized public List<String> convertPdf(String sourceFilename, String dpi) throws Exception
	{
		if(defaultImageFormat.equals(PDFToImageConverter.PNG))
		{
			imageExtension = ".png";
		}
		else 
		{
			imageExtension = ".jpg";
		}
		int maxThread = 4;

		// load PDF document -itext reader
		PdfReader reader = new PdfReader(sourceFilename);

		Rectangle rectangle = reader.getPageSizeWithRotation(1);

		if (rectangle.getWidth() > rectangle.getHeight())
		{
			isWide = true;
		}

		int totalPage = reader.getNumberOfPages();

		System.out.println("Total page to process = " + totalPage);

		return runThreadPool(reader, sourceFilename, totalPage, maxThread, dpi);

	}

	List<String> runThreadPool(PdfReader reader, String sourceFilename, int totalPage, int maxThread, String dpi) throws Exception
	{
		ExecutorService executorService = Executors.newFixedThreadPool(maxThread);

		int i;

		for (i = 0; i < totalPage; i++)
		{
			String outPdfFilename = sourceFilename.substring(0, sourceFilename.indexOf(".pdf")) + "-" + String.format("%03d", i + 1) + ".pdf";
			String outImageFilename = outPdfFilename.substring(0, outPdfFilename.indexOf(".pdf")) + imageExtension;

			listPngFilename.add(outImageFilename);

			GhostScriptTaskThread taskThread = new GhostScriptTaskThread(ghostScriptRunner, defaultImageFormat, reader, outPdfFilename, outImageFilename, i, dpi);

			executorService.execute(taskThread);

		}

		// 스레드풀 종료
		executorService.shutdown();

		executorService.awaitTermination(60 * 60 * 2, TimeUnit.SECONDS);

		return listPngFilename;
	}

}
