package com.twosonsoft.pilot.solution.converter;

public class VoUrlToPdfTask
{
	String url;
	String targetFilename;
	
	String loadCompleteCheckJsFunctionName;
	String completeCheckString;
	
	public String getUrl()
	{
		return url;
	}
	public void setUrl(String url)
	{
		this.url = url;
	}
	public String getTargetFilename()
	{
		return targetFilename;
	}
	public void setTargetFilename(String targetFilename)
	{
		this.targetFilename = targetFilename;
	}
	public String getLoadCompleteCheckJsFunctionName()
	{
		return loadCompleteCheckJsFunctionName;
	}
	public void setLoadCompleteCheckJsFunctionName(String loadCompleteCheckJsFunctionName)
	{
		this.loadCompleteCheckJsFunctionName = loadCompleteCheckJsFunctionName;
	}
	public String getCompleteCheckString()
	{
		return completeCheckString;
	}
	public void setCompleteCheckString(String completeCheckString)
	{
		this.completeCheckString = completeCheckString;
	}
	
	
}
