package com.twosonsoft.pilot.solution.ghostscriptrunner;

public class LinuxRunner implements GhostScriptRunner
{

	@Override
	public String getGhostScriptPath()
	{
		return "/usr/local/bin/gs";
	}

}
