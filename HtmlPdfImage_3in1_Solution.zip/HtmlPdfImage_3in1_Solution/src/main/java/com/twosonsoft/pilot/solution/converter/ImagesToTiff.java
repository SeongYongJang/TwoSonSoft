package com.twosonsoft.pilot.solution.converter;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

public class ImagesToTiff
{
	@SuppressWarnings("rawtypes")
	Iterator writers = ImageIO.getImageWritersByFormatName("tiff");
	ImageWriter writer;

	public ImagesToTiff()
	{
		writer = (ImageWriter) writers.next();
	}

	public void run(List<String> listImageFilename, String outputTiffFilename) throws IOException
	{
		List<BufferedImage> listImage = new ArrayList<BufferedImage>();

		for (String imgFile : listImageFilename)
		{
			System.out.println("Reading >> " + imgFile);
			listImage.add(ImageIO.read(new File(imgFile)));
		}

		ImageOutputStream output = ImageIO.createImageOutputStream(new FileOutputStream(outputTiffFilename));
		try
		{

			writer.setOutput(output);

			ImageWriteParam params = writer.getDefaultWriteParam();
			params.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);

			params.setCompressionType("JPEG");
			params.setCompressionQuality(0.9f);

			writer.prepareWriteSequence(null);

			for (BufferedImage image : listImage)
			{

				writer.writeToSequence(new IIOImage(image, null, null), params);
			}

			// We're done
			writer.endWriteSequence();

		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());

		}
		finally
		{
			output.flush();
			output.close();
			writer.dispose();
		}
	}

	String getFileExtension(String name)
	{
		String extension = "";

		try
		{
			extension = name.substring(name.lastIndexOf("."));
		}
		catch (Exception e)
		{
			extension = "";
		}

		return extension;

	}
}
