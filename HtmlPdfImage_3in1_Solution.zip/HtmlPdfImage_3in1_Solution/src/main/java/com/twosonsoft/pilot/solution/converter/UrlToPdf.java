package com.twosonsoft.pilot.solution.converter;

import static java.nio.file.Files.write;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import io.webfolder.cdp.Launcher;
import io.webfolder.cdp.ProcessManager;
import io.webfolder.cdp.command.Animation;
import io.webfolder.cdp.command.CSS;
import io.webfolder.cdp.command.DOM;
import io.webfolder.cdp.command.Page;
import io.webfolder.cdp.session.Session;
import io.webfolder.cdp.session.SessionFactory;
import io.webfolder.cdp.type.page.GetLayoutMetricsResult;
import io.webfolder.cdp.type.runtime.EvaluateResult;

// URL을 입력받아 chrome headless 모드를 통해 pdf 파일을 생성한다
// TODO : register this class as spring bean
public class UrlToPdf
{
	static int defaultWaitSecond = 1000 * 2;
	
	Launcher launcher;
	List<String> args = new ArrayList<String>();
	SessionFactory factory;

	ProcessManager processManager;

	public UrlToPdf(ProcessManager processManager)
	{
		this.processManager = processManager;
		launcher = new Launcher();
		launcher.setProcessManager(processManager);
		//////////////////////////////////////////////////////////
		// initialize session factory
		init();
	}

	void init()
	{
		args.add("--disable-gpu");
		args.add("--headless");

		factory = launcher.launch(args);
	}

	public void doUrlToPdf(VoUrlToPdfTask voUrlToPdfTask) throws Exception
	{

		String url = voUrlToPdfTask.getUrl();
		String jsFunction = voUrlToPdfTask.getLoadCompleteCheckJsFunctionName();
		//////////////////////////////////////////////////////////////////////////

		String context = factory.createBrowserContext();
		Session session = factory.create(context);
		// init browser running specification
		initDefaultBrowserSpec(session);
		
		// navigate url
		session.navigate(url);
		// wait page
		session.waitDocumentReady();
		// wait status done
		if (jsFunction != null)
		{
			waitJavascriptStatus(session, jsFunction, voUrlToPdfTask.getCompleteCheckString());
		}
		else
		{
			Thread.sleep(defaultWaitSecond);
		}
		
		printToPdf(context, session, voUrlToPdfTask.getTargetFilename());

		factory.disposeBrowserContext(context);

		launcher.getProcessManager().kill();

	}

	void waitJavascriptStatus(Session session, String functionName, String completeString) throws Exception
	{

		EvaluateResult evaluateResult = session.getCommand().getRuntime().evaluate(functionName);

		String status = (String) evaluateResult.getResult().getValue();
		do
		{
			status = (String) evaluateResult.getResult().getValue();
			Thread.sleep(500);
		} while (!completeString.equals(status));

	}
	void initDefaultBrowserSpec(Session session)
	{
		DOM dom = session.getCommand().getDOM();
		dom.enable();

		CSS css = session.getCommand().getCSS();
		css.enable();

		Animation ani = session.getCommand().getAnimation();

		ani.disable();
		
	}

	void printToPdf(String context, Session session, String targetFilename) throws Exception
	{
		Page page = session.getCommand().getPage();
		page.setDeviceMetricsOverride(1024, 768, 1.0, false);

		// recalculate page metrics
		GetLayoutMetricsResult layout = page.getLayoutMetrics();

		int height = layout.getContentSize().getHeight().intValue();

		// change page metrics
		page.setDeviceMetricsOverride(1080, height, 1.0, false);

		// print web page
		byte[] content = page.printToPDF();
		Path path = Paths.get(targetFilename);

		write(path, content);
		session.close();

	}
}
