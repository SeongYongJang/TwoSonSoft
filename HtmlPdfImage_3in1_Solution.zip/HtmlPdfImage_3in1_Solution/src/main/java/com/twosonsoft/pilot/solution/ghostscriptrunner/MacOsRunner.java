package com.twosonsoft.pilot.solution.ghostscriptrunner;

public class MacOsRunner implements GhostScriptRunner
{

	@Override
	public String getGhostScriptPath()
	{
		return "/usr/local/bin/gs";
	}

}
