package com.twosonsoft.pilot.solution.converter;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.twosonsoft.pilot.solution.ghostscriptrunner.GhostScriptRunner;

public class GhostScriptTaskThread implements Runnable
{
	String outPdfFilename;
	String outImageFilename;
	PdfReader reader;
	int index;
	String dpi;
	GhostScriptRunner ghostScriptRunner;
	String imageFormat;

	List<String> commandArgs = new ArrayList<String>();

	public GhostScriptTaskThread(GhostScriptRunner ghostScriptRunner, String imageFormat, PdfReader reader, String outPdfFilename, String outPngFilename, int index, String dpi)
	{
		this.ghostScriptRunner = ghostScriptRunner;
		this.imageFormat = imageFormat;
		
		this.outPdfFilename = outPdfFilename;
		this.outImageFilename = outPngFilename;
		this.reader = reader;
		this.index = index;
		this.dpi = dpi;

		initArguments(dpi);
	}

	void initArguments(String dpi)
	{
		commandArgs.add(ghostScriptRunner.getGhostScriptPath());
		commandArgs.add("-dNumRenderingThreads=2");
		commandArgs.add("-dNOPAUSE");
		commandArgs.add("-q");
		commandArgs.add("-sDEVICE=" + imageFormat);
		commandArgs.add("-r" + dpi);
		commandArgs.add("-dBATCH");
		commandArgs.add("-dFirstPage=1");
		commandArgs.add("-dLastPage=1");
		commandArgs.add("-sOutputFile=" + outImageFilename);
		commandArgs.add(outPdfFilename);

	}

	@Override
	public void run()
	{
		try
		{
			System.out.println("Processing => " + outPdfFilename);
			splitPdf(reader, outPdfFilename, index);
			ProcessBuilder builder = new ProcessBuilder(commandArgs);
			Process process = builder.start();
			process.waitFor();

			// delete splitpdf
			File file = new File(outPdfFilename);
			file.delete();

		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	void splitPdf(PdfReader reader, String splitPdfFilename, int index) throws Exception
	{

		Document document = new Document(reader.getPageSizeWithRotation(1));
		PdfCopy writer = new PdfCopy(document, new FileOutputStream(splitPdfFilename));
		document.open();

		PdfImportedPage page = writer.getImportedPage(reader, index + 1);
		writer.addPage(page);

		document.close();
		writer.close();
	}

	void runGhostscript()
	{

	}

}