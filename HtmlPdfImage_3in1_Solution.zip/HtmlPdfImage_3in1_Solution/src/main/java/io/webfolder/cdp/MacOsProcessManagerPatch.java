package io.webfolder.cdp;

import static java.util.concurrent.TimeUnit.SECONDS;

import java.lang.reflect.Field;

import io.webfolder.cdp.exception.CdpException;

public class MacOsProcessManagerPatch extends ProcessManager
{
	private int pid;

	@Override
	void setProcess(CdpProcess process)
	{
		try
		{
			Field pidField = process.getProcess().getClass().getDeclaredField("pid");
			pidField.setAccessible(true);
			this.pid = (Integer) pidField.get(process.getProcess());
		}
		catch (Throwable e)
		{
			throw new CdpException(e);
		}
		process.getCdp4jProcessId();
	}

	
	@Override
	public boolean kill()
	{
		try
		{
			Process proc = Runtime.getRuntime().exec("kill -TERM " + pid);
			
			proc.waitFor(5, SECONDS);
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
}
